Lead Tracker - Flutter Starter
==============================

What's included:
- pubspec.yaml (dependencies: hive, hive_flutter, path_provider)
- lib/
  - main.dart
  - boxes.dart
  - models/lead.dart  (includes manual Hive TypeAdapter)
  - screens/home_screen.dart
  - screens/add_lead_screen.dart

How to use (quick):
1. Install Flutter and set up Android Studio / VS Code with Flutter plugin.
2. Create a new Flutter project (for example `flutter create lead_tracker_app`).
3. Replace the project's `pubspec.yaml` with the one in this zip (or merge dependencies).
4. Replace the `lib/` folder in the new project with the `lib/` folder from this zip.
5. Run `flutter pub get`.
6. Run the app on an emulator or device: `flutter run`.

Notes:
- This starter uses a manual Hive TypeAdapter (no code generation).
- If you want an APK directly I can guide you to build it locally using `flutter build apk`.
