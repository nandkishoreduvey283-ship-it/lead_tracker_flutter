import 'package:hive/hive.dart';

part 'lead.g.dart'; // NOTE: not used; kept for compatibility comments (no build_runner required)

@HiveType(typeId: 0)
class Lead extends HiveObject {
  @HiveField(0)
  String name;

  @HiveField(1)
  String phone;

  @HiveField(2)
  String status;

  Lead({required this.name, required this.phone, required this.status});
}

// Manually written TypeAdapter (so no code generation is required)
class LeadAdapter extends TypeAdapter<Lead> {
  @override
  final int typeId = 0;

  @override
  Lead read(BinaryReader reader) {
    final numOfFields = reader.readByte();
    final fields = <int, dynamic>{};
    for (var i = 0; i < numOfFields; i++) {
      final key = reader.readByte() as int;
      final value = reader.read();
      fields[key] = value;
    }
    return Lead(
      name: fields[0] as String,
      phone: fields[1] as String,
      status: fields[2] as String,
    );
  }

  @override
  void write(BinaryWriter writer, Lead obj) {
    writer
      ..writeByte(3)
      ..writeByte(0)
      ..write(obj.name)
      ..writeByte(1)
      ..write(obj.phone)
      ..writeByte(2)
      ..write(obj.status);
  }
}
