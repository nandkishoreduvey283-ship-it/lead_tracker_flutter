import 'package:hive/hive.dart';
import 'models/lead.dart';

class Boxes {
  static Box<Lead> getLeads() => Hive.box<Lead>('leads');
}
