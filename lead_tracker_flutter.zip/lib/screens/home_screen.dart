import 'package:flutter/material.dart';
import 'package:hive_flutter/hive_flutter.dart';
import '../boxes.dart';
import '../models/lead.dart';
import 'add_lead_screen.dart';

class HomeScreen extends StatelessWidget {
  const HomeScreen({super.key});

  Color _colorForStatus(String s) {
    switch (s) {
      case 'Interested':
        return Colors.green;
      case 'Follow-up':
        return Colors.orange;
      default:
        return Colors.grey;
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Lead Tracker')),
      body: ValueListenableBuilder(
        valueListenable: Boxes.getLeads().listenable(),
        builder: (context, Box<Lead> box, _) {
          if (box.values.isEmpty) {
            return const Center(child: Text('No Leads Added'));
          }
          return ListView.builder(
            itemCount: box.length,
            itemBuilder: (context, index) {
              Lead lead = box.getAt(index)!;
              return Card(
                margin: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
                child: ListTile(
                  title: Text(lead.name),
                  subtitle: Text(lead.phone),
                  trailing: Container(
                    padding: const EdgeInsets.symmetric(horizontal:8, vertical:4),
                    decoration: BoxDecoration(
                      color: _colorForStatus(lead.status).withOpacity(0.15),
                      borderRadius: BorderRadius.circular(8)
                    ),
                    child: Text(lead.status, style: TextStyle(color: _colorForStatus(lead.status))),
                  ),
                  onTap: () async {
                    // Open edit dialog
                    final result = await showDialog<Lead?>(
                      context: context,
                      builder: (_) => EditLeadDialog(lead: lead),
                    );
                    if (result != null) {
                      // already saved inside dialog
                    }
                  },
                  onLongPress: () {
                    // Delete confirmation
                    showDialog(
                      context: context,
                      builder: (_) => AlertDialog(
                        title: const Text('Delete Lead'),
                        content: const Text('Are you sure you want to delete this lead?'),
                        actions: [
                          TextButton(onPressed: ()=> Navigator.pop(context), child: const Text('Cancel')),
                          TextButton(onPressed: (){
                            lead.delete();
                            Navigator.pop(context);
                          }, child: const Text('Delete')),
                        ],
                      ),
                    );
                  },
                ),
              );
            },
          );
        },
      ),
      floatingActionButton: FloatingActionButton(
        onPressed: () {
          Navigator.push(context,
            MaterialPageRoute(builder: (context) => const AddLeadScreen())
          );
        },
        child: const Icon(Icons.add),
      ),
    );
  }
}

// Edit dialog widget
class EditLeadDialog extends StatefulWidget {
  final Lead lead;
  const EditLeadDialog({super.key, required this.lead});

  @override
  State<EditLeadDialog> createState() => _EditLeadDialogState();
}

class _EditLeadDialogState extends State<EditLeadDialog> {
  late TextEditingController _nameController;
  late TextEditingController _phoneController;
  late String status;

  @override
  void initState() {
    super.initState();
    _nameController = TextEditingController(text: widget.lead.name);
    _phoneController = TextEditingController(text: widget.lead.phone);
    status = widget.lead.status;
  }

  @override
  Widget build(BuildContext context) {
    return AlertDialog(
      title: const Text('Edit Lead'),
      content: SingleChildScrollView(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            TextField(controller: _nameController, decoration: const InputDecoration(labelText: 'Name')),
            TextField(controller: _phoneController, decoration: const InputDecoration(labelText: 'Phone'), keyboardType: TextInputType.phone),
            const SizedBox(height:8),
            DropdownButton<String>(
              value: status,
              items: ['Interested','Not Interested','Follow-up'].map((e)=>DropdownMenuItem(value:e, child: Text(e))).toList(),
              onChanged: (v)=> setState(()=> status = v!),
            )
          ],
        ),
      ),
      actions: [
        TextButton(onPressed: ()=> Navigator.pop(context), child: const Text('Cancel')),
        ElevatedButton(onPressed: (){
          widget.lead.name = _nameController.text;
          widget.lead.phone = _phoneController.text;
          widget.lead.status = status;
          widget.lead.save();
          Navigator.pop(context, widget.lead);
        }, child: const Text('Save'))
      ],
    );
  }
}
